class Money:
    def __init__(self,dollars,cents):
        self.dollar = dollars
        self.cent = cents

    def a__repr__(self):
        return float(self.dollar)+(self.cent/100)

    def addPenny(self):
        self.cent = (self.cent/100) + .01
        return '$'+ str(float(self.dollar)+self.cent)
    def __add__(self,obj):
        return self.a__repr__()+ obj.a__repr__()
    def __sub__(self,obj):
        return self.a__repr__() - obj.a__repr__()




a = Money(3,25)
b = Money(0,75)
print(a.a__repr__())
print(a+b)
print(a-b)
print(a.addPenny())