
def checkSudoku(matrix):
    flag = True
    for line in matrix:
        check = {}
        for value in line:
            if value not in check:
                check[value] = 1
            else:
                check[value] += 1
        if max(check.values()) != 1:
            flag = False

    for row in range(0,9,1):
        check = {}
        for column in range(0,9,1):
            if matrix[row][column] not in check:
                check[matrix[row][column]] = 1
            else:
                check[matrix[row][column]] += 1
        if max(check.values()) != 1:
            flag = False


        print(check)




    return flag
print(checkSudoku([[5,3,4,6,7,8,9,1,2], \
       [6,7,2,1,9,5,3,4,8], \
       [1,9,8,3,4,2,5,6,7], \
       [8,5,9,7,6,1,4,2,3], \
       [4,2,6,8,5,3,7,9,1], \
       [7,1,3,9,2,4,8,5,6], \
       [9,6,1,5,3,7,2,8,4], \
       [2,8,7,4,1,9,6,3,5], \
       [3,4,5,2,8,6,1,7,9]  ]))

print(checkSudoku([[5,3,4,6,7,8,9,1,2],
       [6,7,2,1,9,5,3,4,8],
       [1,9,8,3,4,2,4,6,7],
       [8,5,9,7,6,1,5,2,3],
       [4,2,6,8,5,3,7,9,1],
       [7,1,3,9,2,4,8,5,6],
       [9,6,1,5,3,7,2,8,4],
       [2,8,7,4,1,9,6,3,5],
       [3,4,5,2,8,6,1,7,9]  ]))

