def topngram(file,gram):
    #workingfile = open(file,r)
    line = file.split(' ')
    hold = ''
    gram = ''
    gramlist = []
    for word in line:
        gra
        print(word)

topngram("Hello world I am going brazy",2)