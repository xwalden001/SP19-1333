def tax(income):
    if income <= 9525:
        tax = round((income * .1),2)
        return tax
    else:
        level1tax = round((9525 *.1),2)

    if income >= 9526 and income <= 39700:
        taxedincome = (income - 9525)*.12
        tax = round((taxedincome),2)+(level1tax)
        return tax
    else:
        level2tax = level1tax + round((30174*.12),2)

    if income >= 38701 and income <= 82500:
        tax = round(((income-39700) * .22),2)+(level1tax)+(level2tax)
        return tax
    else:
        level3tax = level1tax + level2tax + round((43,799*.22),2)

    if income < 82500:
        tax = (level1tax)+(level2tax)+(level3tax)+round((income-82500 * .24),2)
        return tax
